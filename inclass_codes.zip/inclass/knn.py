#!/usr/bin/env python3
##
import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_validate

## ---------- create random data with dots shaped in a yin-yang fashion
n = 100
noise = 0.1
x1 = np.random.normal(size=n)
x2 = np.random.normal(size=n)
r = np.sqrt(x1*x1 + x2*x2)
alpha = np.arctan2(x1, x2)
y = np.sign(np.sin(alpha + r*r) +
            np.random.normal(scale=noise, size=n))
X = np.stack((x1, x2), axis=1)

plt.scatter(x1, x2, c=y, edgecolors="k")
plt.show()

## ========== Exercise:
##
## Play with different n and noise values.
## understand what these two parameters are doing

## ---------- kNN example
k = 1
m = KNeighborsClassifier(n_neighbors=k)  # by default Minkowski(2) i.e. Euclidean metric
res = m.fit(X, y)
yhat = m.predict(X)
print("Accuracy:", np.mean(yhat == y))
# note: always A=1 on training data!
# but let's CV:
cv = cross_validate(m, X, y, cv=5, scoring="accuracy")
print("CV accuracy:", np.mean(cv["test_score"]))
# -> you see: CV accuracy is much lower


## ========== Exercise
##
## 1. Try different k values.  Which k gives you the best fit?
## 2. Increase noise.  Does the optimal k change?


## ---------- decision boundary plots
## Now greate the regular grid
ex1 = np.linspace(x1.min(), x1.max(), 100)
ex2 = np.linspace(x2.min(), x2.max(), 100)
xx1, xx2 = np.meshgrid(ex1, ex2)
                           # unlike R-s 'expand.grid', meshgrid creates matrices
g = np.stack((xx1.ravel(), xx2.ravel()), axis=1)
                           # we create the design matrix by stacking the xx1, xx2
                           # after unraveling those into columns
# predict on the grid
hatY = m.predict(g).reshape(100,100)
                           # imshow wants a mtrix, so we reshape the predicted vector into one
plt.figure(figsize=(7,7))
plt.imshow(hatY, extent=(x1.min(), x1.max(), x2.min(), x2.max()),
           interpolation='none', origin='lower',
                           # you need to specify that the image begins from below,
                           # not above, otherwise it will be flipped around
           alpha=0.3)
plt.scatter(x1, x2, c=y, s=100, edgecolors='k')
plt.show()                           


## ---------- create correlated data
## it is a little bit cheating as we create the data
## by stretching/rotating for Mahalanobis...

n = 3500
scale=2.5
alpha = 45*np.pi/180
stretch = 3
x1 = np.random.normal(scale=scale, size=n)
x2 = np.random.normal(scale=scale, size=n)
Xt = np.stack((x1, x2), axis=1)
y = (np.sin(Xt[:,0] + Xt[:,1]) + np.sin(Xt[:,0] - Xt[:,1])).astype(int)
X = Xt @ np.array([[stretch,0],[0,1]]) @ \
    np.array([[np.cos(alpha), -np.sin(alpha)], [np.sin(alpha), np.cos(alpha)]])

ax = plt.subplot(1,1,1)
ax.scatter(X[:,0], X[:,1], c=y, edgecolors="k")
ax.set_aspect("equal")
plt.show()

## ========== Exercise
##
## 1. play with n, scale, alpha, and stretch.
## 2. understand what these parameters are doing
## 3. add noise to this data (check the first example)

## ---------- do kNN w/Euclidean, Mahalanobis metric
k = 1
print("Euclidean:")
m = KNeighborsClassifier(n_neighbors=k)  # Euclidean
cv = cross_validate(m, X, y, cv=5, scoring="accuracy")
print("CV accuracy:", np.mean(cv["test_score"]))

# Mahalanobis: need covariance of data
print("Mahalanobis:")
Sigma = np.cov(X, rowvar=False)
print("Data covariance matrix:\n", Sigma)
m = KNeighborsClassifier(n_neighbors=k, metric="mahalanobis",
                         metric_params={"V":Sigma})
cv = cross_validate(m, X, y, cv=5, scoring="accuracy")
print("CV accuracy:", np.mean(cv["test_score"]))
# Mahalanobis is better.  This is a bit of cheating as we
# created the data to be nice to Mahalanobis, not Euclidean

## ========== Exercise
##
## 1. change alpha: how does Euclidean vs Mahalanobis
##    relative performance change?
## 2. change stretch: ...
