#!/usr/bin/env python3
##
import numpy as np
import os
from matplotlib.image import imread
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

## load data
imagedir = os.path.join("..", "..", "data", "visualizations")
print("reading images from", imagedir)
images = os.listdir(imagedir)
# this contains ~900 images.  Clustering of all of it is slow.
# I recommend to take a subsample of ~100 of it to check how well is it working:
images = np.random.choice(images, 300)
# if it is working fast enough, you can leave the sample out (it may take 5-10 mins)
im1 = imread(os.path.join(imagedir, images[0]))[:,:,1]
imshape = im1.shape
print("All images of size", imshape)
X = np.empty(shape=(len(images), imshape[0]*imshape[1]))
for i, img in enumerate(images):
    print(i, img)
    pixels = imread(os.path.join(imagedir, img))
    X[i,:] = pixels[:,:,1].ravel()
    # note: we select the G color channel only.  If interested,
    # you can play with other channels, or full color images (3x as many pixels)
print("all images read, X:", X.shape, "in all", np.prod(X.shape)/1e6, "megapixels")

## do clustering.  This is slow!  1000 images ~ 10 min
k = 6  # this is the number of clusters
m = KMeans(n_clusters=k).fit(X) 
cl = m.predict(X)  
# 'cl' is the predicted cluster value for each image

## plot images from cluster
## use this function to inspect what kind of images are there in each cluster
def plotclustercenter(m, imshape):
    """
    plot up to 6 cluster centers
    inputs:
    m: fitted kmeans model
    imshape: tuple, shape of the final image
    """
    for c in range(min(6, m.n_clusters)):
        XC = m.cluster_centers_[c,:]
        print(XC)
        XC = m.cluster_centers_[c,:].reshape(imshape)
        ax = plt.subplot(3,2, c+1)
        ax.imshow(XC, cmap='gray')
        plt.suptitle("Cluster " + str(c))
    plt.show()

plotclustercenter(m, imshape)
