In [9]: PS = np.mean(data.spam == True)

In [10]: a
Out[10]: 0.44

In [11]: PV = np.mean(data.viagra == "V")

In [12]: PV
Out[12]: 0.35

In [13]: np.mean(PV_S = data[data.spam == True].viagra == "V")
---------------------------------------------------------------------------
TypeError                                 Traceback (most recent call last)
<ipython-input-13-d07e78d21000> in <module>
----> 1 np.mean(PV_S = data[data.spam == True].viagra == "V")

<__array_function__ internals> in mean(*args, **kwargs)

TypeError: _mean_dispatcher() got an unexpected keyword argument 'PV_S'

In [14]: PV_S = np.mean(data[data.spam == True].viagra == "V")

In [15]: PV_S
Out[15]: 0.5454545454545454

In [16]: PS
Out[16]: 0.44

In [17]: PV
Out[17]: 0.35

In [18]: PV_S
Out[18]: 0.5454545454545454

In [19]: PS_V = PV_S*PS/PV

In [20]: PS_V
Out[20]: 0.6857142857142857
