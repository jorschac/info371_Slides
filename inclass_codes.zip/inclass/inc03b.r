> wvs <- read.delim("data/wvs-satisfaction-subset.csv.bz2")
> dim(wvs)
[1] 90350    10
> head(wvs)
  satisfaction marital income age religious onlyMyReligion religionRules armyRules continent region
1            8       6      5  21         1              2             1         1    Africa     12
2            5       6      6  24         1              1             1         1    Africa     12
3            4       6      6  26         1              3             2         1    Africa     12
4            8       6      5  28         1              3             2         2    Africa     12
5            8       1      7  35         1              3             2         2    Africa     12
6            7       1      5  36         1              1             2         1    Africa     12
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> wvs %>%
   filter(satisfaction > 0, marital > 0, age > 0, religious > 0) %>%
   dim()
wvs %>%
+    filter(satisfaction > 0, marital > 0, age > 0, religious > 0) %>%
+    dim()
> 
[1] 84969    10
> wvs %>%
   filter(satisfaction > 0, marital > 0, age > 0, religious > 0) %>%
   mutate(alone = marital %in% c(3,4,5,6), old = age > 50) %>%
   head()
wvs %>%
+    filter(satisfaction > 0, marital > 0, age > 0, religious > 0) %>%
+    mutate(alone = marital %in% c(3,4,5,6), old = age > 50) %>%
+    head()
> 
  satisfaction marital income age religious onlyMyReligion religionRules armyRules continent region
1            8       6      5  21         1              2             1         1    Africa     12
2            5       6      6  24         1              1             1         1    Africa     12
3            4       6      6  26         1              3             2         1    Africa     12
4            8       6      5  28         1              3             2         2    Africa     12
5            8       1      7  35         1              3             2         2    Africa     12
6            7       1      5  36         1              1             2         1    Africa     12
  alone   old
1  TRUE FALSE
2  TRUE FALSE
3  TRUE FALSE
4  TRUE FALSE
5 FALSE FALSE
6 FALSE FALSE
> wvs %>%
   filter(satisfaction > 0, marital > 0, age > 20, religious > 0) %>%
   mutate(alone = marital %in% c(3,4,5,6), old = age > 50) %>%
   head()
wvs %>%
+    filter(satisfaction > 0, marital > 0, age > 20, religious > 0) %>%
+    mutate(alone = marital %in% c(3,4,5,6), old = age > 50) %>%
+    head()
> 
  satisfaction marital income age religious onlyMyReligion religionRules armyRules continent region
1            8       6      5  21         1              2             1         1    Africa     12
2            5       6      6  24         1              1             1         1    Africa     12
3            4       6      6  26         1              3             2         1    Africa     12
4            8       6      5  28         1              3             2         2    Africa     12
5            8       1      7  35         1              3             2         2    Africa     12
6            7       1      5  36         1              1             2         1    Africa     12
  alone   old
1  TRUE FALSE
2  TRUE FALSE
3  TRUE FALSE
4  TRUE FALSE
5 FALSE FALSE
6 FALSE FALSE
> wvs1 <- wvs %>%
   filter(satisfaction > 0, marital > 0, age > 20, religious > 0) %>%
   mutate(alone = marital %in% c(3,4,5,6), old = age > 50)
wvs1 <- wvs %>%
+    filter(satisfaction > 0, marital > 0, age > 20, religious > 0) %>%
+    mutate(alone = marital %in% c(3,4,5,6), old = age > 50)
> lm(satisfaction ~ alone + old, data=wvs1) %>%
   summary()
lm(satisfaction ~ alone + old, data=wvs1) %>%
+    summary()
> 

Call:
lm(formula = satisfaction ~ alone + old, data = wvs1)

Residuals:
    Min      1Q  Median      3Q     Max 
-5.9873 -1.6186  0.0972  1.4659  3.4659 

Coefficients:
            Estimate Std. Error t value Pr(>|t|)    
(Intercept)  6.98735    0.01133 616.532  < 2e-16 ***
aloneTRUE   -0.36871    0.01711 -21.551  < 2e-16 ***
oldTRUE     -0.08454    0.01708  -4.951 7.41e-07 ***
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 2.252 on 79144 degrees of freedom
Multiple R-squared:  0.006051,	Adjusted R-squared:  0.006026 
F-statistic: 240.9 on 2 and 79144 DF,  p-value: < 2.2e-16

> wvs1 <- wvs %>%
   filter(satisfaction > 0, marital > 0, age > 20, religious > 0) %>%
   mutate(alone = marital %in% c(3,4,5,6), old = age > 50) %>%
   mutate(oldAlone = old*alone)
wvs1 <- wvs %>%
+    filter(satisfaction > 0, marital > 0, age > 20, religious > 0) %>%
+    mutate(alone = marital %in% c(3,4,5,6), old = age > 50) %>%
+    mutate(oldAlone = old*alone)
> lm(satisfaction ~ alone + old + oldAlone, data=wvs1) %>%
   summary()
lm(satisfaction ~ alone + old + oldAlone, data=wvs1) %>%
+    summary()
> 

Call:
lm(formula = satisfaction ~ alone + old + oldAlone, data = wvs1)

Residuals:
    Min      1Q  Median      3Q     Max 
-5.9779 -1.6946  0.0512  1.6410  3.6410 

Coefficients:
            Estimate Std. Error t value Pr(>|t|)    
(Intercept)  6.94882    0.01198 580.190   <2e-16 ***
aloneTRUE   -0.25426    0.02064 -12.318   <2e-16 ***
oldTRUE      0.02911    0.02057   1.415    0.157    
oldAlone    -0.36465    0.03684  -9.897   <2e-16 ***
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 2.251 on 79143 degrees of freedom
Multiple R-squared:  0.00728,	Adjusted R-squared:  0.007242 
F-statistic: 193.5 on 3 and 79143 DF,  p-value: < 2.2e-16

> lm(satisfaction ~ alone*old,   data=wvs1) %>%
   summary()
lm(satisfaction ~ alone*old,   data=wvs1) %>%
+    summary()
> 

Call:
lm(formula = satisfaction ~ alone * old, data = wvs1)

Residuals:
    Min      1Q  Median      3Q     Max 
-5.9779 -1.6946  0.0512  1.6410  3.6410 

Coefficients:
                  Estimate Std. Error t value Pr(>|t|)    
(Intercept)        6.94882    0.01198 580.190   <2e-16 ***
aloneTRUE         -0.25426    0.02064 -12.318   <2e-16 ***
oldTRUE            0.02911    0.02057   1.415    0.157    
aloneTRUE:oldTRUE -0.36465    0.03684  -9.897   <2e-16 ***
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 2.251 on 79143 degrees of freedom
Multiple R-squared:  0.00728,	Adjusted R-squared:  0.007242 
F-statistic: 193.5 on 3 and 79143 DF,  p-value: < 2.2e-16

> 