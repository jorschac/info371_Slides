#!/usr/bin/env python3
##
from sklearn.model_selection import cross_validate
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np

# use the good old boston data
boston = pd.read_csv("../../data/boston.csv.bz2", sep="\t")

## ---------- Best subset selection
## just run through all the models, and pick the best of those
## more precisely:
## run through all models with 0...K features
## for each number of features, pick the best using training data only
## Thereafter compare different models with CV
## we use Boston data

X = boston.drop("medv", axis=1).values
y = boston.medv.values
K = X.shape[1]

## single-feature models
best1 = -1
bestSSE = 1e9
for i1 in range(K):
    print(i1, end=" ")
    Xi = X[:,[i1]]
    m = LinearRegression().fit(Xi, y)
    e = y - m.predict(Xi)
    SSE = e.T @ e
    if SSE < bestSSE:
        bestSSE = SSE
        best1 = (i1, )
print("\nbest 1-variable model:", best1, bestSSE)

## two-feature models
best2 = -1
bestSSE = 1e9
for i1 in range(K):
    print(i1, end=" ")
    for i2 in range(i1+1, K):
        Xi = X[:,[i1, i2]]
        m = LinearRegression().fit(Xi, y)
        e = y - m.predict(Xi)
        SSE = e.T @ e
        if SSE < bestSSE:
            bestSSE = SSE
            best2 = i1, i2
print("\nbest 2-variable model:", best2, bestSSE)

## ---------- Exercise
## use wdbc data
## predict diagnosis using all the numberical features
## find the best 1-feature model
## ... and find the best 2-feature model
## ... and cross-validate and find the overall best model
## (use accuracy for your metric)
## see solutions in a separate file

from sklearn.linear_model import LogisticRegression

wdbc = pd.read_csv("../../data/wdbc.csv.bz2", sep=",")
Xw = wdbc.drop(["id", "diagnosis"], axis=1).values
yw = wdbc.diagnosis.values
Kw = X.shape[1]

# ...

mw = LogisticRegression(solver="lbfgs")



## ---------- examples continue ...
## three-feature models
best3 = -1
bestSSE = 1e9
for i1 in range(K):
    print(i1, end=" ")
    for i2 in range(i1+1, K):
        for i3 in range(i2+1, K):
            Xi = X[:,[i1, i2, i3]]
            m = LinearRegression().fit(Xi, y)
            e = y - m.predict(Xi)
            SSE = e.T @ e
            if SSE < bestSSE:
                bestSSE = SSE
                best3 = i1, i2, i3
print("\nbest 3-variable model:", best3, bestSSE)

## four-feature models
best4 = -1
bestSSE = 1e9
for i1 in range(K):
    print(i1, end=" ")
    for i2 in range(i1+1, K):
        for i3 in range(i2+1, K):
            for i4 in range(i3+1, K):
                Xi = X[:,[i1, i2, i3, i4]]
                m = LinearRegression().fit(Xi, y)
                e = y - m.predict(Xi)
                SSE = e.T @ e
                if SSE < bestSSE:
                    bestSSE = SSE
                    best4 = i1, i2, i3, i4
print("\nbest 4-variable model:", best4, bestSSE)


## ---------- Compare across different k-s

for i in [best1, best2, best3, best4]:
    print(len(i), ":", i)
    Xi = X[:,i]
    m = LinearRegression()
    cv = cross_validate(m, Xi, y, scoring=["neg_mean_squared_error"], cv = 5)
    print(np.mean(cv["test_neg_mean_squared_error"]))


## ---------- algernatively, iterate over all combinations

from itertools import combinations

bestSSEi = []
indicesi = []
for k in range(1, K+1):
    print(k)
    bestSSE = 1e9
    indices = None
    for i in combinations(range(K), k):
        Xi = X[:,i]
        m = LinearRegression().fit(Xi, y)
        e = y - m.predict(Xi)
        SSE = e.T @ e
        if SSE < bestSSE:
            bestSSE = SSE
            indices = i
    bestSSEi.append(bestSSE)
    indicesi.append(indices)
print(bestSSEi)
print(indicesi)
        
## ---------- and compare across k

besti = 0
bestMSE = 1e9
for i in indicesi:
    print(len(i), ":", i, end=" ")
    Xi = X[:,i]
    m = LinearRegression()
    cv = cross_validate(m, Xi, y, scoring=["neg_mean_squared_error"], cv = 5)
    mse = -np.mean(cv["test_neg_mean_squared_error"])
    print(mse)
    if mse < bestMSE:
        bestMSE = mse
        besti = i
print("Overall winner:", besti, bestMSE)

