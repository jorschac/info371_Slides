#!/usr/bin/env python3
##
import pandas as pd
import numpy as np

##
data = pd.read_csv("spam.csv", sep="\t")
print("shape:", data.shape)
print(data.head())
y = data.spam.astype(int)
X = (data.viagra == "V").astype(int)
print("y=", y.head())
print("X=", X.head())

## Compute priors:
PS = np.mean(y)  # Pr(S)
PNS = np.mean(1 - y)  # Pr(NS)
print("Pr(S)=", PS, ", Pr(NS)=", PNS)

## Compute normalizers:
PV = np.mean(X)  # Pr(V)
PNV = np.mean(1 - X)  # Pr(NV)
print("Pr(V)=", PV, ", Pr(NV)=", PNV)

## Compute the conditional probabilities
PV_S = np.mean(X[y == 1])  # Pr(V|S)
PV_NS = np.mean(X[y == 0])  # Pr(V|NS)
print("Pr(V|S)=", PV_S, ", P(V|NS)=", PV_NS)
PNV_S = np.mean(1 - X[y == 1])  # Pr(NV|S) = 1 - Pr(V|S)
PNV_NS = np.mean(1 - X[y == 0])  # Pr(NV|NS) = 1 - Pr(V|NS)
print("Pr(NV|S)=", PNV_S, ", P(NV|NS)=", PNV_NS)  # not really needed

## Compute the posteriors
PS_V = PV_S*PS/PV
PS_NV = PNV_S*PS/PNV
print("Pr(S|V)=", PS_V, ", Pr(S|NV)=", PS_NV)
PNS_V = PV_NS*PNS/PV  # Pr(NS|V) = 1 - Pr(S|V)
PNS_NV = PNV_NS*PNS/PNV  # Pr(NS|NV) = 1 - Pr(S|NV)
print("Pr(NS|V)=", PNS_V, ", Pr(NS|NV)=", PNS_NV)  

## predict
probHat = np.where(X == 1,  # viagra here
                   PS_V,  # predict spam|viagra
                   PS_NV  # othervise spam|no viagra
                   )
yhat = probHat > 0.5  # we say this is spam
print("confusion matrix (on training data)\n",
      pd.crosstab(y, yhat))
print("Accuracy:", np.mean(y == yhat))

