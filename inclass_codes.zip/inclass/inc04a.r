> approval <- read.delim("data/obama-trump.csv.bz2", stringsAsFactors=FALSE)
> head(approval)
                    poll       date  sample approve disapprove spread president
1 NBC News/Wall St. Jrnl 2016-05-17 1000 RV      51         46     +5     Obama
2               FOX News 2016-05-16 1021 RV      48         49     -1     Obama
3          Reuters/Ipsos 2016-05-16  1677 A      48         47     +1     Obama
4      CBS News/NY Times 2016-05-15  1300 A      50         43     +7     Obama
5          Reuters/Ipsos 2016-05-09  1611 A      47         50     -3     Obama
6   The Economist/YouGov 2016-05-08 1389 RV      46         52     -6     Obama
> tail(approval)
                        poll       date  sample approve disapprove spread president
144                   Gallup 2020-01-22  1033 A      49         50     -1     Trump
145        Rasmussen Reports 2020-01-27 1500 LV      49         51     -2     Trump
146               Quinnipiac 2020-01-24 1095 RV      43         52     -9     Trump
147 Politico/Morning Consult 2020-01-25 1992 RV      41         55    -14     Trump
148                  Emerson 2020-01-22 1128 RV      47         48     -1     Trump
149       ABC News/Wash Post 2020-01-22  880 RV      47         50     -3     Trump
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> app <- approval %>%
   select(-poll, -sample, -disapprove, -spread) %>%
   mutate(after = date >= "2020-03-20" | (date < "2017-01-20" & date > "2016-03-20"))
app <- approval %>%
+    select(-poll, -sample, -disapprove, -spread) %>%
+    mutate(after = date >= "2020-03-20" | (date < "2017-01-20" & date > "2016-03-20"))
> app %>% sample_n(10)
         date approve president after
1  2020-02-14      49     Trump FALSE
2  2016-03-30      50     Obama  TRUE
3  2020-02-24      44     Trump FALSE
4  2020-04-05      46     Trump  TRUE
5  2016-03-05      49     Obama FALSE
6  2016-02-13      44     Obama FALSE
7  2020-03-09      45     Trump FALSE
8  2020-03-28      45     Trump  TRUE
9  2020-04-15      46     Trump  TRUE
10 2016-02-15      49     Obama FALSE
> dim(app)
[1] 149   4
> app %>%
   group_by(president, after) %>%
   summarize(mean(approve))
app %>%
+    group_by(president, after) %>%
+    summarize(mean(approve))
> 
# A tibble: 4 x 3
# Groups:   president [2]
  president after `mean(approve)`
  <chr>     <lgl>           <dbl>
1 Obama     FALSE            46.3
2 Obama     TRUE             48.0
3 Trump     FALSE            45.1
4 Trump     TRUE             46.1
> to <- 48 - 46.3
> to
[1] 1.7
> tt <- 46.1 - 45.1
> tt
[1] 1
> tt - to
[1] -0.7
> head(app)
        date approve president after
1 2016-05-17      51     Obama  TRUE
2 2016-05-16      48     Obama  TRUE
3 2016-05-16      48     Obama  TRUE
4 2016-05-15      50     Obama  TRUE
5 2016-05-09      47     Obama  TRUE
6 2016-05-08      46     Obama  TRUE
> lm(approve ~ after*president, data=app) %>% summary()

Call:
lm(formula = approve ~ after * president, data = app)

Residuals:
    Min      1Q  Median      3Q     Max 
-6.3030 -2.0313 -0.1111  1.8889  6.8947 

Coefficients:
                         Estimate Std. Error t value Pr(>|t|)    
(Intercept)               46.3030     0.4135 111.990  < 2e-16 ***
afterTRUE                  1.7282     0.5893   2.933  0.00391 ** 
presidentTrump            -1.1978     0.5195  -2.305  0.02256 *  
afterTRUE:presidentTrump  -0.7224     0.8094  -0.892  0.37362    
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 2.375 on 145 degrees of freedom
Multiple R-squared:  0.1772,	Adjusted R-squared:  0.1602 
F-statistic: 10.41 on 3 and 145 DF,  p-value: 3.033e-06

> lm(approve ~ after*I(president == "Trump"), data=app) %>% summary()

Call:
lm(formula = approve ~ after * I(president == "Trump"), data = app)

Residuals:
    Min      1Q  Median      3Q     Max 
-6.3030 -2.0313 -0.1111  1.8889  6.8947 

Coefficients:
                                      Estimate Std. Error t value Pr(>|t|)    
(Intercept)                            46.3030     0.4135 111.990  < 2e-16 ***
afterTRUE                               1.7282     0.5893   2.933  0.00391 ** 
I(president == "Trump")TRUE            -1.1978     0.5195  -2.305  0.02256 *  
afterTRUE:I(president == "Trump")TRUE  -0.7224     0.8094  -0.892  0.37362    
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 2.375 on 145 degrees of freedom
Multiple R-squared:  0.1772,	Adjusted R-squared:  0.1602 
F-statistic: 10.41 on 3 and 145 DF,  p-value: 3.033e-06
