In [25]: x = np.random.normal(size=20)

In [26]: X = np.stack((np.ones(20), x), axis=1)

In [27]: X
Out[27]: 
array([[ 1.        , -0.34125599],
       [ 1.        ,  0.13451712],
       [ 1.        ,  1.86956552],
       [ 1.        ,  0.05705716],
       [ 1.        , -0.42976675],
       [ 1.        , -1.22719015],
       [ 1.        ,  0.77399926],
       [ 1.        , -0.75187076],
       [ 1.        , -0.11374508],
       [ 1.        ,  0.7130868 ],
       [ 1.        ,  0.0523706 ],
       [ 1.        , -0.38622864],
       [ 1.        , -0.17271986],
       [ 1.        ,  0.89834902],
       [ 1.        , -0.01963622],
       [ 1.        ,  0.2426732 ],
       [ 1.        ,  0.42284847],
       [ 1.        , -0.33453935],
       [ 1.        ,  0.32793911],
       [ 1.        , -0.27680916]])

In [28]: y = X[:,1] + np.random.normal(scale=0.3, size=20)

In [29]: plt.scatter(X[:,1], y)
Out[29]: <matplotlib.collections.PathCollection at 0x7fc4bcfce110>

In [30]: beta = np.array([1,2])

In [31]: beta
Out[31]: array([1, 2])

In [32]: X @ beta
Out[32]: 
array([ 0.31748801,  1.26903425,  4.73913104,  1.11411433,  0.14046649,
       -1.4543803 ,  2.54799852, -0.50374152,  0.77250984,  2.4261736 ,
        1.1047412 ,  0.22754272,  0.65456027,  2.79669804,  0.96072756,
        1.4853464 ,  1.84569693,  0.33092129,  1.65587823,  0.44638168])

In [33]: X.shape
Out[33]: (20, 2)

In [34]: beta.shape
Out[34]: (2,)

In [35]: (X @ beta).shape
Out[35]: (20,)

In [36]: e = y - X@beta

In [37]: e.T @ e
Out[37]: 37.82639919980147

In [38]: SSE = e.T @ e

In [39]: beta
Out[39]: array([1, 2])

In [40]: SSE
Out[40]: 37.82639919980147

In [41]: beta = np.array([1, 1])

In [42]: e = y - X@beta

In [43]: SSE = e.T @ e

In [44]: SSE
Out[44]: 22.493699557253926

In [45]: beta = np.array([0, 1])

In [46]: e = y - X@beta

In [47]: SSE = e.T @ e

In [48]: SSE
Out[48]: 2.3140208236830144

In [49]: np.linalg.inv(X.T @ X) @ X.t @ y
---------------------------------------------------------------------------
AttributeError                            Traceback (most recent call last)
<ipython-input-49-3479fba9a990> in <module>
----> 1 np.linalg.inv(X.T @ X) @ X.t @ y

AttributeError: 'numpy.ndarray' object has no attribute 't'

In [50]: np.linalg.inv(X.T @ X) @ X.T @ y
Out[50]: array([0.01219152, 0.76806652])

In [51]: beta = np.linalg.inv(X.T @ X) @ X.T @ y

In [52]: e = y - X@beta

In [53]: SSE = e.T @ e

In [54]: SSE
Out[54]: 1.860192448446234
