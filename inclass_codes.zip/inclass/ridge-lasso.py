#!/usr/bin/env python3
##
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression, Ridge, Lasso

## create random data
NT = 12  # total number of training data
NV = 15
NX = 7  # number of attributes
u = 0.1  # randomness in predictors
np.random.seed(4)
xT = np.random.normal(size=NT).reshape((-1,1))
xV = np.linspace(xT.min(), xT.max(), NV).reshape((-1,1))  # 15 uniformly spaced validation datapoints
yT = xT + np.random.normal(scale=0.3, size=(NT,1))
yV = xV + np.random.normal(scale=0.3, size=(NV,1))
XT = np.random.normal(size=(NT,NX)) + xT
XV = np.random.normal(size=(NV,NX)) + xV
#
ax = plt.subplot(1,1,1)
ax.scatter(xT, yT, marker="o", c="k", label="training")
ax.scatter(xV, yV, marker="o", c="r", label="validation")
ax.legend()
ax.set_xlabel("x")
ax.set_ylabel("y")
plt.show()

## linear regression
mlr = LinearRegression().fit(XT, yT)
yhatT = mlr.predict(XT)
yhatV = mlr.predict(XV)
eT = yT - yhatT
eV = yV - yhatV
R2T = 1 - np.var(eT)/np.var(yT)
R2V = 1 - np.var(eV)/np.var(yV)
print("R2: training", R2T, "validation", R2V)

## Exercise:
## pick a few random columns from X
## run a regression not on the whole X but on those random columns
## Do you get less overfitting?


## make a nice plot
from matplotlib import collections as mc

ax = plt.subplot(1,1,1)
ax.scatter(xT, yT, marker="o", c="k", label="true training")
ax.scatter(xV, yV, marker="o", c="r", label="true validation")
ax.scatter(xT, yhatT, marker="x", c="k", label="pred training")
ax.scatter(xV, yhatV, marker="x", c="r", label="pred validation")
segmentsT = [[(xT[i].item(), yT[i].item()), (xT[i].item(), yhatT[i].item())] for i in range(len(xT))]
lcT = mc.LineCollection(segmentsT, linestyle="dotted", colors="k")
ax.add_collection(lcT)
segmentsV = [[(xV[i].item(), yV[i].item()), (xV[i].item(), yhatV[i].item())] for i in range(len(xV))]
lcV = mc.LineCollection(segmentsV, linestyle="dotted", colors="r")
ax.add_collection(lcV)
ax.legend()
ax.set_xlabel("x")
ax.set_ylabel("y")
plt.show()


## ridge
m_ridge = Ridge(alpha=1).fit(XT, yT)
yhatT_ridge = m_ridge.predict(XT)
yhatV_ridge = m_ridge.predict(XV)
eT_ridge = yT - yhatT_ridge
eV_ridge = yV - yhatV_ridge
R2T_ridge = 1 - np.var(eT_ridge)/np.var(yT)
R2V_ridge = 1 - np.var(eV_ridge)/np.var(yV)
print("Ridge R2: training", R2T_ridge, "validation", R2V_ridge)

## Exercise:
## plot ridge regression predictions in a similar fashion as we plotted OLS above
## (do a new figure to avoid too much mess)
## How does it look like compared to the OLS?
## Set alpha to 0.  How does the picture change?
## Set alpha to 1000.  What happens now?


## lasso
m_lasso = Lasso(alpha=0.5).fit(XT, yT)
yhatT_lasso = m_lasso.predict(XT).reshape((-1,1))
yhatV_lasso = m_lasso.predict(XV).reshape((-1,1))
eT_lasso = yT - yhatT_lasso
eV_lasso = yV - yhatV_lasso
R2T_lasso = 1 - np.var(eT_lasso)/np.var(yT)
R2V_lasso = 1 - np.var(eV_lasso)/np.var(yV)
print("Lasso R2: training", R2T_lasso, "validation", R2V_lasso)

## Exercise:
## Try different alpha values b/w 0 and 1.  What happens to validation R2?
## cross-validate a range of alphas to find the best alpha in terms of test R2
