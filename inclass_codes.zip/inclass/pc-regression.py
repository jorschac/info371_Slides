#!/usr/bin/env python3
##
from sklearn.model_selection import cross_validate
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf

## Example with random data
n = 100
x1 = np.random.normal(size=n)
x2 = x1 + np.random.normal(scale=0.5, size=n)
y = ((x1 + x2 + np.random.normal(scale=2.5, size=n)) > 0).astype(int)
df = pd.DataFrame({"x1":x1, "x2":x2, "y":y})
print("Original data:\n", df.sample(10))
X = np.stack((x1, x2), axis=1)
ax = plt.subplot(1, 1, 1)
ax.scatter(x1, x2, c=y, edgecolors='k')
ax.set_aspect("equal")
plt.show()

## Set up models

mlogit = smf.logit("y ~ x1 + x2", data=df).fit()
print(mlogit.summary())
# does not work well: both x1, x2 not really significant

# repeat with sklearn, and cross-validate
mlogistic = LogisticRegression(solver="lbfgs", C=1e9).fit(X, y)
print("sklearn coefficients:", mlogistic.coef_)
cv = cross_validate(mlogistic, X, y, scoring=["accuracy"], cv = 5)
print("Accuracy:", np.mean(cv["test_accuracy"]))


## PCA and rotate data
pca = PCA().fit(X)
print("components:\n", pca.components_.T)
# note: this is very close to 45deg rotation matrix
Xrot = pca.transform(X)
dfrot = pd.DataFrame({"pc1":Xrot[:,0], "pc2":Xrot[:,1], "y":y})
print("Rotated data:\n", dfrot.sample(10))
ax = plt.subplot(1, 1, 1)
ax.scatter(Xrot[:,0], Xrot[:,1], c=y, edgecolors='k')
ax.set_aspect("equal")
plt.show()

## PCA regression with both coefficients
mlogit = smf.logit("y ~ pc1 + pc2", data=dfrot).fit()
print(mlogit.summary())
# x1
mpc = LogisticRegression(solver="lbfgs", C=1e9).fit(Xrot, y)
print("sklearn coefficients:", mpc.coef_)
cv = cross_validate(mpc, Xrot, y, scoring=["accuracy"], cv = 5)
print("Accuracy:", np.mean(cv["test_accuracy"]))

## PCA regression with the first coefficient only
mlogit1 = smf.logit("y ~ pc1", data=dfrot).fit()
print(mlogit1.summary())
# does not work well: both x1, x2 not really significant
mpc = LogisticRegression(solver="lbfgs", C=1e9).fit(Xrot[:,[0]], y)
print("sklearn coefficients:", mpc.coef_)
cv = cross_validate(mpc, Xrot[:,[0]], y, scoring=["accuracy"], cv = 5)
print("Accuracy:", np.mean(cv["test_accuracy"]))
# accuracy almost the same but now we just had a single
# explantory variable: we have a simpler model that works equally well
