In [4]: # (x - mean(x))/std(x)

In [5]: X = np.stack((np.random.normal(scale=0.1, size=10), np.random.normal(scale=10, size=10)), 1)
---------------------------------------------------------------------------
NameError                                 Traceback (most recent call last)
<ipython-input-5-dd4f52f41f28> in <module>
----> 1 X = np.stack((np.random.normal(scale=0.1, size=10), np.random.normal(scale=10, size=10)), 1)

NameError: name 'np' is not defined

In [6]: import numpy as np

In [7]: X = np.stack((np.random.normal(scale=0.1, size=10), np.random.normal(scale=10, size=10)), 1)

In [8]: X
Out[8]: 
array([[-2.83577855e-03, -7.26997141e+00],
       [-5.02658342e-02,  1.24565177e+01],
       [ 2.23647747e-01,  3.26215133e+00],
       [ 3.93098015e-02, -2.07577154e+00],
       [ 1.70068441e-01,  1.34233720e+01],
       [ 3.20810557e-02, -7.60385619e+00],
       [-8.30902395e-03, -5.76974036e+00],
       [ 1.15886177e-01,  3.21714935e+00],
       [ 6.66739165e-02, -6.35904491e+00],
       [-1.72238197e-04,  4.53816904e+00]])

In [9]: for j in range(X.shape[1]):
   ...:   mean = np.mean(X[:,j])
   ...:   sd = np.std(X[:,j])
   ...:   X[:,j] = (X[:,j] - mean)/sd
   ...: 

In [10]: X
Out[10]: 
array([[-0.74707113, -1.07642606],
       [-1.32375083,  1.56073895],
       [ 2.00663533,  0.33157642],
       [-0.23464288, -0.38203173],
       [ 1.35518979,  1.68999431],
       [-0.3225338 , -1.12106195],
       [-0.81361774, -0.87586545],
       [ 0.69641317,  0.32556026],
       [ 0.09806449, -0.9546475 ],
       [-0.7146864 ,  0.50216274]])

In [11]: import pandas pd
  File "<ipython-input-11-6bfc1f40d5ca>", line 1
    import pandas pd
                   ^
SyntaxError: invalid syntax


In [12]: import pandas as pd

In [13]: import os

In [14]: os.getcwd()
Out[14]: '/home/otoomet'

In [15]: os.chdir("tyyq/teaching/info371")

In [19]: wdbc = pd.read_csv("../data/wdbc.csv.bz2", sep="\t")

In [20]: wdbc.head()
Out[20]: 
  id,diagnosis,radius.mean,texture.mean,perimeter.mean,area.mean,smoothness.mean,compactness.mean,concavity.mean,concpoints.mean,symmetry.mean,fracdim.mean,radius.se,texture.se,perimeter.se,area.se,smoothness.se,compactness.se,concavity.se,concpoints.se,symmetry.se,fracdim.se,radius.worst,texture.worst,perimeter.worst,area.worst,smoothness.worst,compactness.worst,concavity.worst,concpoints.worst,symmetry.worst,fracdim.worst
0  842302,M,17.99,10.38,122.8,1001,0.1184,0.2776,...                                                                                                                                                                                                                                                                                                                                                                                       
1  842517,M,20.57,17.77,132.9,1326,0.08474,0.0786...                                                                                                                                                                                                                                                                                                                                                                                       
2  84300903,M,19.69,21.25,130,1203,0.1096,0.1599,...                                                                                                                                                                                                                                                                                                                                                                                       
3  84348301,M,11.42,20.38,77.58,386.1,0.1425,0.28...                                                                                                                                                                                                                                                                                                                                                                                       
4  84358402,M,20.29,14.34,135.1,1297,0.1003,0.132...                                                                                                                                                                                                                                                                                                                                                                                       

In [21]: wdbc = pd.read_csv("../data/wdbc.csv.bz2", sep=",")

In [22]: wdbc.head()
Out[22]: 
         id diagnosis  radius.mean  texture.mean  perimeter.mean  area.mean  smoothness.mean  ...  area.worst  smoothness.worst  compactness.worst  concavity.worst  concpoints.worst  symmetry.worst  fracdim.worst
0    842302         M        17.99         10.38          122.80     1001.0          0.11840  ...      2019.0            0.1622             0.6656           0.7119            0.2654          0.4601        0.11890
1    842517         M        20.57         17.77          132.90     1326.0          0.08474  ...      1956.0            0.1238             0.1866           0.2416            0.1860          0.2750        0.08902
2  84300903         M        19.69         21.25          130.00     1203.0          0.10960  ...      1709.0            0.1444             0.4245           0.4504            0.2430          0.3613        0.08758
3  84348301         M        11.42         20.38           77.58      386.1          0.14250  ...       567.7            0.2098             0.8663           0.6869            0.2575          0.6638        0.17300
4  84358402         M        20.29         14.34          135.10     1297.0          0.10030  ...      1575.0            0.1374             0.2050           0.4000            0.1625          0.2364        0.07678

[5 rows x 32 columns]

In [23]: X = wdbc.drop(["id", "diagnosis"])
---------------------------------------------------------------------------
KeyError                                  Traceback (most recent call last)
<ipython-input-23-e29abac99903> in <module>
----> 1 X = wdbc.drop(["id", "diagnosis"])

~/anaconda3/lib/python3.7/site-packages/pandas/core/frame.py in drop(self, labels, axis, index, columns, level, inplace, errors)
   4115             level=level,
   4116             inplace=inplace,
-> 4117             errors=errors,
   4118         )
   4119 

~/anaconda3/lib/python3.7/site-packages/pandas/core/generic.py in drop(self, labels, axis, index, columns, level, inplace, errors)
   3912         for axis, labels in axes.items():
   3913             if labels is not None:
-> 3914                 obj = obj._drop_axis(labels, axis, level=level, errors=errors)
   3915 
   3916         if inplace:

~/anaconda3/lib/python3.7/site-packages/pandas/core/generic.py in _drop_axis(self, labels, axis, level, errors)
   3944                 new_axis = axis.drop(labels, level=level, errors=errors)
   3945             else:
-> 3946                 new_axis = axis.drop(labels, errors=errors)
   3947             result = self.reindex(**{axis_name: new_axis})
   3948 

~/anaconda3/lib/python3.7/site-packages/pandas/core/indexes/base.py in drop(self, labels, errors)
   5338         if mask.any():
   5339             if errors != "ignore":
-> 5340                 raise KeyError("{} not found in axis".format(labels[mask]))
   5341             indexer = indexer[~mask]
   5342         return self.delete(indexer)

KeyError: "['id' 'diagnosis'] not found in axis"

In [24]: X = wdbc.drop(["id", "diagnosis"], axis=1)

In [25]: X.head()
Out[25]: 
   radius.mean  texture.mean  perimeter.mean  area.mean  smoothness.mean  compactness.mean  ...  smoothness.worst  compactness.worst  concavity.worst  concpoints.worst  symmetry.worst  fracdim.worst
0        17.99         10.38          122.80     1001.0          0.11840           0.27760  ...            0.1622             0.6656           0.7119            0.2654          0.4601        0.11890
1        20.57         17.77          132.90     1326.0          0.08474           0.07864  ...            0.1238             0.1866           0.2416            0.1860          0.2750        0.08902
2        19.69         21.25          130.00     1203.0          0.10960           0.15990  ...            0.1444             0.4245           0.4504            0.2430          0.3613        0.08758
3        11.42         20.38           77.58      386.1          0.14250           0.28390  ...            0.2098             0.8663           0.6869            0.2575          0.6638        0.17300
4        20.29         14.34          135.10     1297.0          0.10030           0.13280  ...            0.1374             0.2050           0.4000            0.1625          0.2364        0.07678

[5 rows x 30 columns]

In [26]: from sklearn.decomposition import PCA

In [29]: m = PCA().fit(X)

In [30]: m.components_.T[:3,:]
Out[32]: 
array([[ 5.08623202e-03,  9.28705650e-03, -1.23425821e-02,
        -3.42380473e-02,  3.54561138e-02, -1.31213101e-01,
         3.35131912e-02, -7.54924585e-02, -3.50549264e-01,
         1.39559852e-01, -4.19346972e-01,  7.35141931e-01,
         2.18087182e-01,  8.10260113e-02, -1.37865559e-01,
        -1.41957144e-01,  4.42129324e-02,  8.97292328e-02,
        -2.10057742e-02, -8.01074429e-02,  5.94747777e-02,
        -8.72363409e-03, -4.57847381e-03,  2.82894830e-02,
         3.59617411e-03, -1.60336173e-03, -2.79341068e-03,
        -3.25869730e-03, -5.12865809e-04,  6.48447162e-04],
       [ 2.19657026e-03, -2.88160658e-03, -6.35497857e-03,
        -3.62415111e-01, -4.43187450e-01, -2.13486089e-01,
        -7.84253475e-01, -6.87405638e-02,  4.08376429e-03,
         7.66679112e-02,  2.90168453e-02, -1.77040388e-03,
         4.23058843e-03,  1.98471260e-03,  7.07543943e-03,
        -3.71772553e-03, -1.74411881e-03, -1.41458884e-04,
        -1.24960485e-03,  2.12853660e-04, -5.08486619e-04,
         3.25522689e-04,  5.70803677e-04,  7.33059897e-05,
         4.32289948e-04, -6.85637302e-04, -2.03286434e-04,
        -1.08812487e-04, -1.28702530e-04,  4.67664637e-06],
       [ 3.50763298e-02,  6.27480827e-02, -7.16694814e-02,
        -3.29281417e-01,  3.13382893e-01, -8.40324225e-01,
         1.89074737e-01,  8.39642267e-02,  1.32828034e-01,
        -8.92113884e-02,  2.68885270e-03, -8.17809788e-02,
        -2.51180394e-02, -5.22865768e-03,  1.34434455e-02,
         2.06841238e-02, -1.08282412e-02, -1.37775702e-02,
         6.16356938e-04,  1.09397982e-02, -1.00150532e-02,
         3.17936985e-03,  1.25149830e-03, -3.58436087e-03,
        -3.07763932e-04,  1.33993328e-04, -1.48499782e-04,
         5.92481499e-04,  2.82547547e-04, -1.53201140e-04]])

In [33]: m.components_.T[:,:3]
Out[33]: 
array([[ 5.08623202e-03,  9.28705650e-03, -1.23425821e-02],
       [ 2.19657026e-03, -2.88160658e-03, -6.35497857e-03],
       [ 3.50763298e-02,  6.27480827e-02, -7.16694814e-02],
       [ 5.16826469e-01,  8.51823720e-01, -2.78944181e-02],
       [ 4.23694535e-06, -1.48194356e-05,  7.26596827e-05],
       [ 4.05260047e-05, -2.68862249e-06,  1.01754350e-04],
       [ 8.19399539e-05,  7.51419574e-05,  2.65989729e-04],
       [ 4.77807775e-05,  4.63501038e-05,  3.60471764e-05],
       [ 7.07804332e-06, -2.52430431e-05,  1.41290958e-04],
       [-2.62155251e-06, -1.61197148e-05,  5.06376971e-05],
       [ 3.13742507e-04, -5.38692831e-05,  6.06156709e-03],
       [-6.50984008e-05,  3.48370414e-04,  6.23377635e-03],
       [ 2.23634150e-03,  8.19640791e-04,  4.38560369e-02],
       [ 5.57271669e-02,  7.51112451e-03,  9.90245878e-01],
       [-8.05646029e-07,  1.49438131e-06,  4.34471433e-05],
       [ 5.51918197e-06,  1.27357957e-05,  1.27658711e-04],
       [ 8.87094462e-06,  2.86921009e-05,  2.07365800e-04],
       [ 3.27915009e-06,  9.36007477e-06,  4.78855144e-05],
       [-1.24101836e-06,  1.22647432e-05,  1.14411270e-04],
       [-8.54530832e-08,  2.89683790e-07,  2.43158370e-05],
       [ 7.15473257e-03, -5.68673345e-04, -1.55659935e-02],
       [ 3.06736622e-03, -1.32152605e-02, -3.15446196e-02],
       [ 4.94576447e-02, -1.85961117e-04, -9.23133791e-02],
       [ 8.52063392e-01, -5.19742358e-01, -3.93186778e-02],
       [ 6.42005481e-06, -7.68565692e-05, -4.21307399e-05],
       [ 1.01275937e-04, -2.56104144e-04, -7.64833237e-04],
       [ 1.68928625e-04, -1.75471479e-04, -8.46552237e-04],
       [ 7.36658178e-05, -3.05051743e-05, -3.33596393e-04],
       [ 1.78986262e-05, -1.57042845e-04, -3.49992952e-04],
       [ 1.61356159e-06, -5.53071662e-05, -4.09371692e-05]])

In [34]: Xrot = m.transform(X)

In [35]: type(Xrot)
Out[35]: numpy.ndarray

In [36]: type(X)
Out[36]: pandas.core.frame.DataFrame

In [37]: Xrot.shape
Out[37]: (569, 30)

In [38]: X.shape
Out[38]: (569, 30)

In [39]: Xrot[:10,:6]
Out[39]: 
array([[ 1.16014257e+03, -2.93917544e+02,  4.85783976e+01,
        -8.71197531e+00,  3.20004861e+01,  1.26541481e+00],
       [ 1.26912244e+03,  1.56301818e+01, -3.53945342e+01,
         1.78612832e+01, -4.33487404e+00, -2.25871776e-01],
       [ 9.95793889e+02,  3.91567432e+01, -1.70975298e+00,
         4.19934010e+00, -4.66529118e-01, -2.65281116e+00],
       [-4.07180803e+02, -6.73803198e+01,  8.67284783e+00,
        -1.17598673e+01,  7.11546109e+00,  1.29943616e+00],
       [ 9.30341180e+02,  1.89340742e+02,  1.37480074e+00,
         8.49918256e+00,  7.61328922e+00,  1.02116044e+00],
       [-2.11591259e+02, -7.98774463e+01, -1.47945698e+00,
        -2.89929532e+00,  7.62051499e+00,  7.44868271e-01],
       [ 8.21210900e+02, -4.71496699e+01, -3.22549991e+01,
         3.03846993e-01,  3.15331269e+00,  1.50580915e+00],
       [-2.50899776e+01, -7.41860146e+01,  1.17907139e+01,
        -7.10824707e+00,  2.97709597e+00, -1.57790777e+00],
       [-1.91292834e+02, -4.21264896e+01, -6.29131241e+00,
        -1.05373520e+01,  1.71116946e+00, -3.22509660e-01],
       [-2.38292863e+02, -6.53865069e+01, -3.63214959e+00,
        -1.26091476e+01, -8.84956815e+00, -2.08268223e+00]])

In [40]: Xrot[:10,:5]
Out[40]: 
array([[ 1.16014257e+03, -2.93917544e+02,  4.85783976e+01,
        -8.71197531e+00,  3.20004861e+01],
       [ 1.26912244e+03,  1.56301818e+01, -3.53945342e+01,
         1.78612832e+01, -4.33487404e+00],
       [ 9.95793889e+02,  3.91567432e+01, -1.70975298e+00,
         4.19934010e+00, -4.66529118e-01],
       [-4.07180803e+02, -6.73803198e+01,  8.67284783e+00,
        -1.17598673e+01,  7.11546109e+00],
       [ 9.30341180e+02,  1.89340742e+02,  1.37480074e+00,
         8.49918256e+00,  7.61328922e+00],
       [-2.11591259e+02, -7.98774463e+01, -1.47945698e+00,
        -2.89929532e+00,  7.62051499e+00],
       [ 8.21210900e+02, -4.71496699e+01, -3.22549991e+01,
         3.03846993e-01,  3.15331269e+00],
       [-2.50899776e+01, -7.41860146e+01,  1.17907139e+01,
        -7.10824707e+00,  2.97709597e+00],
       [-1.91292834e+02, -4.21264896e+01, -6.29131241e+00,
        -1.05373520e+01,  1.71116946e+00],
       [-2.38292863e+02, -6.53865069e+01, -3.63214959e+00,
        -1.26091476e+01, -8.84956815e+00]])

In [41]: Xrot[:10,:3]
Out[41]: 
array([[1160.1425737 , -293.91754364,   48.57839763],
       [1269.12244319,   15.63018184,  -35.39453423],
       [ 995.79388896,   39.15674324,   -1.70975298],
       [-407.18080253,  -67.38031982,    8.67284783],
       [ 930.34118015,  189.34074158,    1.37480074],
       [-211.59125901,  -79.87744626,   -1.47945698],
       [ 821.21089989,  -47.14966994,  -32.25499909],
       [ -25.08997758,  -74.18601461,   11.79071389],
       [-191.29283443,  -42.12648962,   -6.29131241],
       [-238.29286318,  -65.38650692,   -3.63214959]])

In [42]: from sklearn.linear_model import LogisticRegression

In [47]: ml = LogisticRegression().fit(Xrot[:,:3], y)
---------------------------------------------------------------------------
NameError                                 Traceback (most recent call last)
<ipython-input-49-b67544d4a52d> in <module>
----> 1 ml = LogisticRegression().fit(Xrot[:,:3], y)

NameError: name 'y' is not defined

In [50]: ml = LogisticRegression().fit(Xrot[:,:3], wdbc.diagnosis)
/home/otoomet/anaconda3/lib/python3.7/site-packages/sklearn/linear_model/logistic.py:432: FutureWarning: Default solver will be changed to 'lbfgs' in 0.22. Specify a solver to silence this warning.
  FutureWarning)

In [51]: ml = LogisticRegression(solver="lbfgs").fit(Xrot[:,:3], wdbc.diagnosis)

In [52]: ml.coef_
Out[52]: array([[ 0.01368987, -0.0320045 ,  0.04282147]])

In [53]: yhat = ml.predict(Xrot[:,:3])

In [54]: yhat[:30]
Out[54]: 
array(['M', 'M', 'M', 'B', 'M', 'M', 'M', 'M', 'B', 'M', 'M', 'M', 'M',
       'B', 'B', 'M', 'M', 'M', 'M', 'B', 'B', 'B', 'M', 'M', 'M', 'M',
       'M', 'M', 'M', 'M'], dtype=object)

In [55]: np.mean(yhat == wdbc.diagnosis)
Out[55]: 0.9314586994727593

In [56]: mn = LogisticRegression(solver="lbfgs").fit(X[:,[1,11,21]], wdbc.diagnosis)
---------------------------------------------------------------------------
TypeError                                 Traceback (most recent call last)
<ipython-input-56-f2e831257de8> in <module>
----> 1 mn = LogisticRegression(solver="lbfgs").fit(X[:,[1,11,21]], wdbc.diagnosis)

~/anaconda3/lib/python3.7/site-packages/pandas/core/frame.py in __getitem__(self, key)
   2993             if self.columns.nlevels > 1:
   2994                 return self._getitem_multilevel(key)
-> 2995             indexer = self.columns.get_loc(key)
   2996             if is_integer(indexer):
   2997                 indexer = [indexer]

~/anaconda3/lib/python3.7/site-packages/pandas/core/indexes/base.py in get_loc(self, key, method, tolerance)
   2895                 )
   2896             try:
-> 2897                 return self._engine.get_loc(key)
   2898             except KeyError:
   2899                 return self._engine.get_loc(self._maybe_cast_indexer(key))

pandas/_libs/index.pyx in pandas._libs.index.IndexEngine.get_loc()

pandas/_libs/index.pyx in pandas._libs.index.IndexEngine.get_loc()

TypeError: '(slice(None, None, None), [1, 11, 21])' is an invalid key

In [57]: type(X)
Out[57]: pandas.core.frame.DataFrame

In [58]: mn = LogisticRegression(solver="lbfgs").fit(X.iloc[:,[1,11,21]], wdbc.diagnosis)

In [59]: yhatn = nm.predict(X.iloc[:,[1,11,21]])
---------------------------------------------------------------------------
NameError                                 Traceback (most recent call last)
<ipython-input-59-5f67804756c2> in <module>
----> 1 yhatn = nm.predict(X.iloc[:,[1,11,21]])

NameError: name 'nm' is not defined

In [60]: yhatn = mn.predict(X.iloc[:,[1,11,21]])

In [61]: np.mean(yhatn == wdbc.diagnosis)
Out[61]: 0.7627416520210897

In [62]: np.mean(np.random.choice(["M", "C"], X.shape[0]) == wdbc.diagnosis)
Out[62]: 0.17750439367311072

In [63]: np.mean(np.random.choice(["M", "B"], X.shape[0]) == wdbc.diagnosis)
Out[63]: 0.4991212653778559

In [64]: wdbc.diagnosis[:10]
Out[64]: 
0    M
1    M
2    M
3    M
4    M
5    M
6    M
7    M
8    M
9    M
Name: diagnosis, dtype: object

In [65]: wdbc.diagnosis[201:210]
Out[65]: 
201    M
202    M
203    M
204    B
205    M
206    B
207    M
208    B
209    B
Name: diagnosis, dtype: object
