#!/usr/bin/env python3
##
import numpy as np

## and perceptron
x1 = 0
x2 = 1
w1 = 1
w2 = 1
b = 1.5
z = x1*w1 + x2*w2
y = int(z > b)
print(x1, "AND", x2, "=", y)

## do this in vector form
x = np.array([0, 1])
w = np.array([1, 1])
b = 1.5
z = x.T @ w  # inner (dot) product
y = (z > b).astype(int)
# use astype here, not int as 'astype' is vectorized
print(x1, "AND", x2, "=", y)

## Make a function
def AND(x1, x2):
    x = np.array([x1, x2])
    w = np.array([1, 1])
    b = 1.5
    y = (x.T @ w > b).astype(int)
    # use astype here, not int as 'astype' is vectorized
    print(x1, "AND", x2, "=", y)

AND(0, 0)
AND(1, 0)
AND(1, 1)

## Exercise: make yourself OR perceptron as a function

## XOR perceptron
# first in non-vector, non-function form
x1 = 1
x2 = 1
w_h11 = 1  # node h1, input x1
w_h12 = 1  # node h1, input x2
b_h1 = 1.5  # do AND
w_h21 = 1  # node h2, input x1
w_h22 = 1  # node h2, input x2
b_h2 = 0.5  # do OR
w_y1 = -1  # subtract AND
w_y2 = 1  # add OR
b_y = 0.5  # split between 1, 0
#
h1 = int(w_h11*x1 + w_h12*x2 > b_h1)
h2 = int(w_h21*x1 + w_h22*x2 > b_h2)
y = int(w_y1*h1 + w_y2*h2 > b_y)
print(x1, "XOR", x2, "=", y)

## Do in vector form
x = np.array([1, 0])
w_h1 = np.array([1, 1])
b_h1 = 1.5  # do AND
w_h2 = np.array([1, 1])
b_h2 = 0.5  # do OR
w_y = np.array([-1, 1])
b_y = 0.5  # split between 1, 0
#
h1 = (x.T @ w_h1 > b_h1).astype(int)
h2 = (x.T @ w_h2 > b_h2).astype(int)
h = np.array([h1, h2])
y = (h.T @ w_y > b_y).astype(int)
print(x[0], "XOR", x[1], "=", y)

## Exercise: convert this to a function
## Play with this function and different values.  See
## if it predicts correctly

## Matrix form:
x = np.array([1, 1])
W_h = np.array([[1,1], [1,1]])  # all hidden layer weights in a matrix
b_h = np.array([1.5, 0.5])  # do AND, OR
w_y = np.array([-1, 1])
b_y = 0.5  # split between 1, 0
#
h = (x.T @ W_h > b_h).astype(int)
y = (h.T @ w_y > b_y).astype(int)
print(x[0], "XOR", x[1], "=", y)
# neural networks are usually presented, computed in matrix form
