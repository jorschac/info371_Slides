> moon <- readODS::read_ods("../data/moon-jae-in-approval.ods", sheet=2)
Parsed with column specification:
cols(
  year = col_double(),
  month = col_double(),
  week = col_double(),
  positive = col_double(),
  negative = col_double()
)
> moon
   year month week positive negative
1  2019    12    1       48       45
2  2019    12    2       49       43
3  2019    12    3       46       44
4  2019    12    4       NA       NA
5  2020     1    1       NA       NA
6  2020     1    2       47       43
7  2020     1    3       45       46
8  2020     1    4       NA       NA
9  2020     1    5       41       50
10 2020     2    1       44       49
11 2020     2    2       44       49
12 2020     2    3       45       46
13 2020     2    4       42       51
14 2020     3    1       44       48
15 2020     3    2       49       45
16 2020     3    3       49       42
17 2020     3    4       55       39
18 2020     4    1       56       36
19 2020     4    2       57       35
20 2020     4    3       59       33
> moon %>% mutate(date = ISOdate(year, month, 7*(week - 1) + 1))
Error in moon %>% mutate(date = ISOdate(year, month, 7 * (week - 1) +  : 
  could not find function "%>%"
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> moon %>% mutate(date = ISOdate(year, month, 7*(week - 1) + 1))
   year month week positive negative                date
1  2019    12    1       48       45 2019-12-01 12:00:00
2  2019    12    2       49       43 2019-12-08 12:00:00
3  2019    12    3       46       44 2019-12-15 12:00:00
4  2019    12    4       NA       NA 2019-12-22 12:00:00
5  2020     1    1       NA       NA 2020-01-01 12:00:00
15 2020     3    2       49       45 2020-03-08 12:00:00
16 2020     3    3       49       42 2020-03-15 12:00:00
17 2020     3    4       55       39 2020-03-22 12:00:00
18 2020     4    1       56       36 2020-04-01 12:00:00
19 2020     4    2       57       35 2020-04-08 12:00:00
20 2020     4    3       59       33 2020-04-15 12:00:00
> approval <- moon %>%
   mutate(date = ISOdate(year, month, 7*(week - 1) + 1))
approval <- moon %>%
+    mutate(date = ISOdate(year, month, 7*(week - 1) + 1))
> ggplot(approval, aes(date, positive)) + geom_line()
Error in ggplot(approval, aes(date, positive)) : 
  could not find function "ggplot"
> library(ggplot2)
> ggplot(approval, aes(date, positive)) + geom_line()
> ggplot(approval %>% na.omit(), aes(date, positive)) + geom_line()
> 
> approval <- approval %>%
    mutate(after = date > as.Date("2020-03-01"))
approval <- approval %>%
+     mutate(after = date > as.Date("2020-03-01"))
> 
Warning message:
Incompatible methods ("Ops.POSIXt", "Ops.Date") for ">" 
> approval <- approval %>%
    mutate(after = as.Date(date) > as.Date("2020-03-01"))
approval <- approval %>%
+     mutate(after = as.Date(date) > as.Date("2020-03-01"))
> approval
   year month week positive negative                date after
1  2019    12    1       48       45 2019-12-01 12:00:00 FALSE
2  2019    12    2       49       43 2019-12-08 12:00:00 FALSE
3  2019    12    3       46       44 2019-12-15 12:00:00 FALSE
4  2019    12    4       NA       NA 2019-12-22 12:00:00 FALSE
5  2020     1    1       NA       NA 2020-01-01 12:00:00 FALSE
6  2020     1    2       47       43 2020-01-08 12:00:00 FALSE
7  2020     1    3       45       46 2020-01-15 12:00:00 FALSE
8  2020     1    4       NA       NA 2020-01-22 12:00:00 FALSE
9  2020     1    5       41       50 2020-01-29 12:00:00 FALSE
10 2020     2    1       44       49 2020-02-01 12:00:00 FALSE
11 2020     2    2       44       49 2020-02-08 12:00:00 FALSE
12 2020     2    3       45       46 2020-02-15 12:00:00 FALSE
13 2020     2    4       42       51 2020-02-22 12:00:00 FALSE
14 2020     3    1       44       48 2020-03-01 12:00:00 FALSE
15 2020     3    2       49       45 2020-03-08 12:00:00  TRUE
16 2020     3    3       49       42 2020-03-15 12:00:00  TRUE
17 2020     3    4       55       39 2020-03-22 12:00:00  TRUE
18 2020     4    1       56       36 2020-04-01 12:00:00  TRUE
19 2020     4    2       57       35 2020-04-08 12:00:00  TRUE
20 2020     4    3       59       33 2020-04-15 12:00:00  TRUE
> approval <- approval %>%
    mutate(after = as.Date(date) >= as.Date("2020-03-01"))
approval <- approval %>%
+     mutate(after = as.Date(date) >= as.Date("2020-03-01"))
> approval
   year month week positive negative                date after
1  2019    12    1       48       45 2019-12-01 12:00:00 FALSE
2  2019    12    2       49       43 2019-12-08 12:00:00 FALSE
3  2019    12    3       46       44 2019-12-15 12:00:00 FALSE
4  2019    12    4       NA       NA 2019-12-22 12:00:00 FALSE
5  2020     1    1       NA       NA 2020-01-01 12:00:00 FALSE
6  2020     1    2       47       43 2020-01-08 12:00:00 FALSE
7  2020     1    3       45       46 2020-01-15 12:00:00 FALSE
8  2020     1    4       NA       NA 2020-01-22 12:00:00 FALSE
9  2020     1    5       41       50 2020-01-29 12:00:00 FALSE
10 2020     2    1       44       49 2020-02-01 12:00:00 FALSE
11 2020     2    2       44       49 2020-02-08 12:00:00 FALSE
12 2020     2    3       45       46 2020-02-15 12:00:00 FALSE
13 2020     2    4       42       51 2020-02-22 12:00:00 FALSE
14 2020     3    1       44       48 2020-03-01 12:00:00  TRUE
15 2020     3    2       49       45 2020-03-08 12:00:00  TRUE
16 2020     3    3       49       42 2020-03-15 12:00:00  TRUE
17 2020     3    4       55       39 2020-03-22 12:00:00  TRUE
18 2020     4    1       56       36 2020-04-01 12:00:00  TRUE
19 2020     4    2       57       35 2020-04-08 12:00:00  TRUE
20 2020     4    3       59       33 2020-04-15 12:00:00  TRUE
> summary(lm(positive ~ after), data=approval, subset = year > 2019)
Error in eval(predvars, data, env) : object 'positive' not found
> summary(lm(positive ~ after, data=approval, subset = year > 2019))

Call:
lm(formula = positive ~ after, data = approval, subset = year > 
    2019)

Residuals:
   Min     1Q Median     3Q    Max 
-8.714 -2.750  0.500  2.821  6.286 

Coefficients:
            Estimate Std. Error t value Pr(>|t|)    
(Intercept)   44.000      1.549  28.414 2.24e-12 ***
afterTRUE      8.714      2.190   3.979  0.00183 ** 
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 4.097 on 12 degrees of freedom
  (2 observations deleted due to missingness)
Multiple R-squared:  0.5689,	Adjusted R-squared:  0.5329 
F-statistic: 15.83 on 1 and 12 DF,  p-value: 0.001829
