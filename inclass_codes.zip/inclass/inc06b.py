In [13]: n = 100

In [14]: x1 = np.random.normal(size=n)

In [15]: x2 = np.random.normal(size=n)

In [16]: x3 = np.random.normal(size=n)

In [17]: x4 = np.random.normal(size=n)

In [18]: y = x1 + np.random.normal(size=n)

In [19]: import matplotlib.pyplot as plt

In [20]: plt.scatter(x1, y)
Out[20]: <matplotlib.collections.PathCollection at 0x7f1c300ff0d0>

In [21]: plt.scatter(x2, y)
Out[21]: <matplotlib.collections.PathCollection at 0x7f1c3a2890d0>

In [22]: X = np.stack((x1, x2, x3, x4), axis=1)

In [23]: X.shape
Out[23]: (100, 4)

In [24]: m = LinearRegression()

In [25]: res = m.fit(X, y)

In [26]: res.coef_
Out[28]: array([ 0.97925671, -0.03794575, -0.01472101,  0.08403646])

In [29]: m.score(X, y)
Out[29]: 0.5645804038190296

In [30]: cv = cross_validate(m, X, y, cv=5)

In [31]: cv
Out[31]: 
{'fit_time': array([0.00087523, 0.00076079, 0.00120711, 0.00080872, 0.00059867]),
 'score_time': array([0.00737643, 0.00075173, 0.00469589, 0.00046086, 0.00044274]),
 'test_score': array([0.41763655, 0.12419555, 0.58310997, 0.62126523, 0.71463573])}

In [32]: cv["test_score"]
Out[32]: array([0.41763655, 0.12419555, 0.58310997, 0.62126523, 0.71463573])

In [33]: np.mean(cv["test_score"])
Out[33]: 0.4921686060875956

In [34]: 

In [34]: 

In [34]: X.shape
Out[34]: (100, 4)

In [35]: X[:,[1]].shape
Out[35]: (100, 1)

In [36]: X[:,[0]].shape
Out[36]: (100, 1)

In [37]: X[:,0].shape
Out[37]: (100,)

In [38]: X[:,[0]].shape
Out[38]: (100, 1)

In [39]: cv1 = cross_validate(m, X[:,[0]], y, cv=5)

In [40]: cv["test_score"]
Out[40]: array([0.41763655, 0.12419555, 0.58310997, 0.62126523, 0.71463573])

In [41]: np.mean(cv["test_score"])
Out[41]: 0.4921686060875956

In [42]: cv1["test_score"]
Out[42]: array([0.40829235, 0.14941833, 0.59508296, 0.63221547, 0.71572402])

In [43]: np.mean(cv1["test_score"])
Out[43]: 0.5001466287221565

In [44]: 

In [44]: cv2 = cross_validate(m, X[:,[0,1]], y
               cv=5)
    ...:   File "<ipython-input-51-a1f507b699b6>", line 2
    cv=5)
     ^
SyntaxError: invalid syntax


In [52]: cv2 = cross_validate(m, X[:,[0,1]], y,
               cv=5)
    ...: 
In [53]: np.mean(cv2["test_score"])
Out[53]: 0.49652526987043333

In [54]: cv3 = cross_validate(m, X, y,
               scoring="neg_mean_squared_error",
               cv=5)
    ...:     ...: 
In [55]: cv3
Out[55]: 
{'fit_time': array([0.00100827, 0.00047183, 0.00045848, 0.00234151, 0.0008018 ]),
 'score_time': array([0.00031137, 0.00025845, 0.00027728, 0.00043035, 0.0003264 ]),
 'test_score': array([-1.31737926, -1.49967531, -0.98572922, -0.75710512, -0.89287502])}

In [56]: cv3["test_score"]
Out[56]: array([-1.31737926, -1.49967531, -0.98572922, -0.75710512, -0.89287502])

In [57]: np.mean(cv3["test_score"])
Out[57]: -1.0905527847473828

In [58]: -np.mean(cv3["test_score"])
Out[58]: 1.0905527847473828

In [59]: ---------------------------------------------------------------------------
IndexError                                Traceback (most recent call last)
<ipython-input-59-ae592a3705d0> in <module>
----> 1 import codecs, os;__pyfile = codecs.open('''/tmp/py32461MEQ''', encoding='''utf-8''');__code = __pyfile.read().encode('''utf-8''');__pyfile.close();os.remove('''/tmp/py32461MEQ''');exec(compile(__code, '''/home/otoomet/tyyq/teaching/info371/demo/cv.py''', 'exec'));

~/tyyq/teaching/info371/demo/cv.py in <module>
     61 
     62 i = [1, 2, 4]
---> 63 Xi = X[:, i]
     64 m = LinearRegression()
     65 # ...

IndexError: index 4 is out of bounds for axis 1 with size 4

In [60]: 
In [61]: Xi.shape
Out[61]: (506, 3)

In [62]: cv = cross_validate(m, X[:,[1,2,4]], y,
  vc = 5)
    ...: ---------------------------------------------------------------------------
TypeError                                 Traceback (most recent call last)
<ipython-input-62-88811421cc34> in <module>
      1 cv = cross_validate(m, X[:,[1,2,4]], y,
----> 2   vc = 5)

TypeError: cross_validate() got an unexpected keyword argument 'vc'

In [63]: cv = cross_validate(m, X[:,[1,2,4]], y,
   cv = 5)
    ...: 
In [64]: cv["test_score"]
Out[64]: array([-0.27070676,  0.04730853, -0.42518937, -0.04403806, -0.36922206])

In [65]: cv = cross_validate(m, X[:,[1,2,4]], y,
score="neg_mean_squared_error",
cv = 5)
    ...:     ...: ---------------------------------------------------------------------------
TypeError                                 Traceback (most recent call last)
<ipython-input-65-8d70f8bd7e46> in <module>
      1 cv = cross_validate(m, X[:,[1,2,4]], y,
      2 score="neg_mean_squared_error",
----> 3 cv = 5)

TypeError: cross_validate() got an unexpected keyword argument 'score'

In [66]: cv = cross_validate(m, X[:,[1,2,4]], y,
scoring="neg_mean_squared_error",
cv = 5)
    ...:     ...: 
In [67]: cv["test_score"]
Out[67]: 
array([ -43.88410602,  -86.72993842, -114.13943047,  -91.57451187,
        -36.40530988])

In [68]: -np.men(cv["test_score"])
---------------------------------------------------------------------------
AttributeError                            Traceback (most recent call last)
<ipython-input-68-29b7b87b430c> in <module>
----> 1 -np.men(cv["test_score"])

AttributeError: module 'numpy' has no attribute 'men'

In [69]: -np.mean(cv["test_score"])
Out[69]: 74.54665933227122
