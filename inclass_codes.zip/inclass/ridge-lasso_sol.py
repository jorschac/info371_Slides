#!/usr/bin/env python3
##
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression, Ridge, Lasso

## play with random columns
cols = np.random.choice(XT.shape[1], 3)  # 3 columns
XTc = XT[:, cols]
XVc = XV[:, cols]
mlr = LinearRegression().fit(XTc, yT)
yhatT = mlr.predict(XTc)
yhatV = mlr.predict(XVc)
eT = yT - yhatT
eV = yV - yhatV
R2T = 1 - np.var(eT)/np.var(yT)
R2V = 1 - np.var(eV)/np.var(yV)
print("R2: training", R2T, "validation", R2V)
# does not seem to be much better...

## plot ridge regression
ax = plt.subplot(1,1,1)
ax.scatter(xT, yT, marker="o", c="k", label="true training")
ax.scatter(xV, yV, marker="o", c="r", label="true validation")
ax.scatter(xT, yhatT_ridge, marker="x", c="k", label="pred training")
ax.scatter(xV, yhatV_ridge, marker="x", c="r", label="pred validation")
segmentsT = [[(xT[i].item(), yT[i].item()), (xT[i].item(), yhatT_ridge[i].item())] for i in range(len(xT))]
lcT = mc.LineCollection(segmentsT, linestyle="dotted", colors="k")
ax.add_collection(lcT)
segmentsV = [[(xV[i].item(), yV[i].item()), (xV[i].item(), yhatV_ridge[i].item())] for i in range(len(xV))]
lcV = mc.LineCollection(segmentsV, linestyle="dotted", colors="r")
ax.add_collection(lcV)
ax.legend()
ax.set_xlabel("x")
ax.set_ylabel("y")
plt.show()

## Cross-validate lasso
from sklearn.model_selection import cross_validate

alphas = np.logspace(-3, 1, 20)
for alpha in alphas:
    m_lasso = Lasso(alpha=alpha)
    cv = cross_validate(m_lasso, XT, yT, cv=5, scoring="r2")
    print(alpha, np.mean(cv["test_score"]))
