#!/usr/bin/env python3
##
import pandas as pd
import numpy as np

## create data
emails = ["viagra is good in life",
          "life is good",
          "viagra in life"]
spam = [1, 0, 0]

# create vocabulary
vocabulary = set()  # make a set to only include one copy of each word
for email in emails:
    vocabulary |= set(email.split())  # add words to vocabulary
vocabulary = list(vocabulary)  # make it a list to preserve order
vocabulary.sort()  # order alphabetically
print(vocabulary)

# create DTM (which email contains which words
DTM = np.empty(shape=(len(emails), len(vocabulary)))
DTM = pd.DataFrame(DTM, columns = vocabulary)  # make it dataframe
# so we have words as columns for better understanding
for i in range(len(emails)):
    DTM.iloc[i,:] = [word in emails[i] for word in vocabulary]
DTM = DTM.astype(int)  # convert to numbers for clarity
# but usually you can use logicals too
print(DTM)    

y = np.array(spam)

## Compute probabilities
# priors:
print("  priors")
PS1 = np.mean(y)  # Pr(S = 1)
PS0 = np.mean(1 - y)  # Pr(S = 0)
print("Pr(S=1)=", PS1, ", Pr(S=0)=", PS0)

# Compute normalizers:
print("  normalizers")
PW1 = np.mean(DTM, axis=0)  # Pr(W=1)
PW0 = np.mean(1 - DTM, axis=0)  # Pr(W=0)
print("Pr(W=1):\n", PW1, "\nPr(W=0)\n", PW0)

# Compute the conditional probabilities
print("  conditional probabilities")
PW1_S1 = np.mean(DTM[y == 1], axis=0)  # Pr(W=1|S=1)
PW1_S0 = np.mean(DTM[y == 0], axis=0)  # Pr(W=1|S=0)
print("Pr(W=1|S=1):\n", PW1_S0, "\nP(W=1|S=0):\n", PW1_S0)
# compute probabilities for "no word", not really needed as those are
# just 1 - probability "word"
PW0_S1 = np.mean(1 - DTM[y == 1], axis=0)  # Pr(W=0|S=1) = 1 - Pr(W=1|S=1)
PW0_S0 = np.mean(1 - DTM[y == 0], axis=0)  # Pr(W=0|S=0) = 1 - Pr(W=1|S=0)
print("Pr(W=0|S=1):\n", PW0_S1, "\nP(W=0|S=1):\n", PW0_S0)  # not really needed

## Compute the posteriors: multiply by either PW1 or PW0, depending on
## if W=1 or W=0
print("  likelihood")
# likelihood of spam
LS1_W = PS1  # only prior
for i in range(DTM.shape[1]):  # walk over all columns
    # (words) in the vocabulary
    LS1_W *= np.where(DTM.iloc[:,i] == 1, PW1_S1[i], PW0_S1[i])
# note: we ignore the normalizer here!    
print("L(S=1|W):", LS1_W)
# problem here: you get zeros: no spam example in training data
# that does not contain any of the words, hence if an email
# does not contain a word, we get 0 probability it is spam
# that is bad, we need smoothing (see below)

# probability of non-spam
LS0_W = PS0  # only prior
for i in range(DTM.shape[1]):  # walk over all columns
    # (words) in the vocabulary
    LS0_W *= np.where(DTM.iloc[:,i] == 1, PW1_S0[i], PW0_S0[i])
print("L(S=0|W):", LS0_W)    

## use log likelihoods instead of likelihoods
## just take log of the probabilities and add together
print("  log-likelihood")
# log likelihood of spam
lS1_W = np.log(PS1)  # only prior
for i in range(DTM.shape[1]):  # walk over all columns
    # (words) in the vocabulary
    lS1_W += np.log(np.where(DTM.iloc[:,i] == 1, PW1_S1[i], PW0_S1[i]))
# note: we ignore the normalizer here!    
print("l(S=1|W):", lS1_W)

# probability of non-spam
lS0_W = np.log(PS0)  # only prior
for i in range(DTM.shape[1]):  # walk over all columns
    # (words) in the vocabulary
    lS0_W += np.log(np.where(DTM.iloc[:,i] == 1, PW1_S0[i], PW0_S0[i]))
print("l(S=0|W):", lS0_W)    

## predict
## new email: "life is life"
print("  new email")
new = "no viagra no life"
bow = np.array([int(w in new) for w in vocabulary])

# likelihood of spam
lS1_W = np.log(PS1)  # only prior
for i in range(len(bow)):  # walk over all columns
    # (words) in the vocabulary
    lS1_W += np.log(np.where(bow[i] == 1, PW1_S1[i], PW0_S1[i]))
# note: we ignore the normalizer here!    
print("l(S=1|W):", lS1_W)
# probability of non-spam
lS0_W = np.log(PS0)  # only prior
for i in range(len(bow)):  # walk over all columns
    # (words) in the vocabulary
    lS0_W += np.log(np.where(bow[i] == 1, PW1_S0[i], PW0_S0[i]))
print("l(S=0|W):", lS0_W)    

## exercise: add Laplace smoothing.  This is equivalent to
## two additional observations:
## one spam that contains all words
## one non-spam that contains all words
ys = np.hstack((y, np.array([1,0])))  # first spam, second non-spam
DTMs = np.vstack((DTM, np.ones((2, DTM.shape[1]))))  # two additional
# observations that contain all the words.
# 
# now repeat all the above with these new DTM-s
