#!/usr/bin/env python
# coding: utf-8
##
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

## 1 Random example
# 
# Create a random 1-D dataset that depicts a noisy step function.
# We create it as
# y = 1(x < 0) + \epsilon
#
# show it all on a plot
n = 100
X = np.random.normal(size=(n,1))
y = (X < 0) + np.random.normal(scale=0.3, size=(n,1))
# this create y as a 2-D array.  We want it to be a 1-D array:
y = y.ravel()
print("x shape", X.shape)
print("y shape", y.shape)
plt.scatter(X, y)
plt.show()

## 2 Estimate regression tree on this data
# 
# Use DecisionTreeRegressor() for this.  
# Plot $\hat y$ vs $x$, and $\hat y$ vs $y$.
# 
# Compute RMSE of your model (on the training data).
m = DecisionTreeRegressor(max_depth=1)  # only ask for a single split
m.fit(X, y)
yhat = m.predict(X)
e = y - yhat
rmse = np.sqrt(e.T @ e)
print("RMSE on training data", rmse)
# now predict on a regular grid 'newX' for plotting
newX = np.linspace(np.min(X), np.max(X), 100).reshape((-1,1))
newY = m.predict(newX)
plt.scatter(X, y, edgecolors='k')
plt.plot(newX, newY)
plt.xlabel("x")
plt.ylabel("y")
plt.show()

## 3 But how can we find the best split point?  Let's just try them all!
## order X, and loop over all splitting points in ordered X
xlevels = np.sort(np.unique(X))
# np.unique not really relevant here as we have continuous X
# but it matters more in real data where overlapping values are common
for threshold in xlevels[1:]:
    # split data into left and right branch
    # do not take the first value as noting is smaller than that
    left = (X < threshold).ravel()  # we need 1-D array to index y...
    XL = X[left,:]
    yL = y[left]
    nL = len(yL)
    XR = X[~left,:]
    yR = y[~left]
    nR = len(yR)
    # compute variances in both branches
    meanL = np.mean(yL)
    eL = yL - meanL
    mseL = eL.T @ eL
    meanR = np.mean(yR)
    eR = yR - meanR
    mseR = eR.T @ eR
    mse = mseL + mseR
    print("threshold=", threshold, ", MSE=", mse)

# if we want to build a full tree, we will continue this procedure on both
# left and right branches, and walk over all predictors


## 4 Categorize Iris data
# 
iris = pd.read_csv("../../data/iris.csv.bz2", sep="\t")
print(iris.sample(3))
X = iris.drop("Species", axis=1).values
y = iris.Species.values
# y is the species' name.  This is fine for Trees but not for plotting
# convert it to numeric for plotting:
# setosa -> 0, versicolor -> 1, virginica -> 2
y = (y == "versicolor") + (y == "virginica")*2
m = DecisionTreeClassifier()
m.fit(X, y)
yhat = m.predict(X)
A = np.mean(yhat == y)
print("Accuracy (training data) =", A)
# Well... this was training data!


## 5 Decision boundary plot: we do it in the same way as in the kNN demo
## But we need 2-D data, not 4-D data
## So we repeat the above with 2-D data
X2 = X[:,:2]  # take two first columns
m.fit(X2, y)
yhat = m.predict(X2)
A = np.mean(yhat == y)
print("Accuracy (2D training data) =", A)
# it is still training data
ex1 = np.linspace(X2[:,0].min(), X2[:,0].max(), 100)
ex2 = np.linspace(X2[:,1].min(), X2[:,1].max(), 100)
xx1, xx2 = np.meshgrid(ex1, ex2)
                           # unlike R-s 'expand.grid', meshgrid creates matrices
g = np.stack((xx1.ravel(), xx2.ravel()), axis=1)
                           # we create the design matrix by stacking the xx1, xx2
                           # after unraveling those into columns
# predict on the grid
ygrid = m.predict(g).reshape(100,100)
                           # imshow wants a mtrix, so we reshape the predicted vector into one
plt.figure(figsize=(7,7))
plt.imshow(ygrid, extent=(X2[:,0].min(), X2[:,0].max(), X2[:,1].min(), X2[:,1].max()),
           interpolation='none', origin='lower',
                           # you need to specify that the image begins from below,
                           # not above, otherwise it will be flipped around
           alpha=0.3)
plt.scatter(X[:,0], X[:,1], c=y, s=100, edgecolors='k')
plt.xlabel(iris.columns[0])
plt.ylabel(iris.columns[1])
plt.show()                           


## 6 But all that was training data...  Let's do CV!
## Use again all 4 features
from sklearn.model_selection import cross_validate
cv = cross_validate(m, X, y, scoring=["accuracy"], cv=10)
print("10-fold CV accuracy:", np.mean(cv["test_accuracy"]))
# 0.96: pretty good :-)
