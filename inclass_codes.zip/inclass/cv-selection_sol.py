#!/usr/bin/env python3
##
from sklearn.model_selection import cross_validate
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np

## ---------- Exercise
## 1. read boston housing data
## 2. split the data into target ("medv") and features (everything else)
## 3. select a few features (e.g. 1,2,4)
## 4. run a linear regression model using these features
## 5. cross-validate the MSE
## 6. try some other features and repeat

## Here is the code skeleton:
boston = pd.read_csv("../../data/boston.csv.bz2", sep="\t")
X = boston.drop("medv", axis=1).values
y = boston.medv.values
m = LinearRegression()

i1 = [1, 2, 4]
Xi = X[:,i1]
cv1 = cross_validate(m, Xi, y, scoring=["neg_mean_squared_error"], cv = 5)
print("MSE of model 1:", -np.mean(cv1["test_neg_mean_squared_error"]))

i2 = [2, 3, 5, 10]
Xi = X[:,i2]
cv2 = cross_validate(m, Xi, y, scoring=["neg_mean_squared_error"], cv = 5)
print("MSE of model 2:", -np.mean(cv2["test_neg_mean_squared_error"]))

i3 = [2, 3, 5, 6, 7, 8, 9, 10]
Xi = X[:,i3]
cv3 = cross_validate(m, Xi, y, scoring=["neg_mean_squared_error"], cv = 5)
print("MSE of model 3:", -np.mean(cv3["test_neg_mean_squared_error"]))


## ---------- Exercise
## use wdbc data
## predict diagnosis using all the numberical features
## find the best 1-feature model
## ... and find the best 2-feature model
## ... and cross-validate and find the overall best model
## (use accuracy for your metric)
## see solutions in a separate file

from sklearn.linear_model import LogisticRegression

wdbc = pd.read_csv("../../data/wdbc.csv.bz2", sep=",")
Xw = wdbc.drop(["id", "diagnosis"], axis=1).values
yw = wdbc.diagnosis.values
Kw = X.shape[1]

## single-feature models
best1 = -1
bestAccuracy = 0
for i1 in range(Kw):
    print(i1, end=" ")
    Xi = Xw[:,[i1]]
    mw = LogisticRegression(solver="lbfgs").fit(Xi, yw)
    accuracy = np.mean(mw.predict(Xi) == yw)
    if accuracy > bestAccuracy:
        bestAccuracy = accuracy
        best1 = (i1, )
print("\nbest 1-variable model:", best1, bestAccuracy)

## two-feature models
best2 = -1
bestAccuracy = 0
for i1 in range(Kw):
    print(i1, end=" ")
    for i2 in range(Kw):
        Xi = Xw[:,[i1, i2]]
        mw = LogisticRegression(solver="lbfgs").fit(Xi, yw)
        accuracy = np.mean(mw.predict(Xi) == yw)
        if accuracy > bestAccuracy:
            bestAccuracy = accuracy
            best2 = (i1, i2)
print("\nbest 2-variable model:", best2, bestAccuracy)

## CV over features:
mw = LogisticRegression(solver="lbfgs")
cv1 = cross_validate(mw, Xw[:, best1], yw, scoring=["accuracy"], cv = 5)
print("Accuracy of model 1:", np.mean(cv1["test_accuracy"]))
cv2 = cross_validate(mw, Xw[:, best2], yw, scoring=["accuracy"], cv = 5)
print("Accuracy of model 1:", np.mean(cv2["test_accuracy"]))

