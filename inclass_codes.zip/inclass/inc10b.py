##
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer

##
msg = ["viagra is good in life",
       "life is good",
        "viagra in life"]
y = np.array([1, 0, 0])

v = CountVectorizer(binary=True)
X = v.fit_transform(msg).toarray()

##
import pandas as pd
dtm = pd.DataFrame(X,
                   columns=v.get_feature_names())

##
PS1 = np.mean(y)
PS0 = np.mean(1 - y)

XS1 = X[y == 1]
XS0 = X[y == 0]

# presence of words
PW1_S1 = np.mean(XS1, axis=0)
PW1_S0 = np.mean(XS0, axis=0)

# now absence of words
PW0_S1 = np.mean(1 - XS1, axis=0)
PW0_S0 = np.mean(1 - XS0, axis=0)

logPS1 = np.log(PS1)
logPS0 = np.log(PS0)
logPW1_S1 = np.log(PW1_S1)
logPW1_S0 = np.log(PW1_S0)
logPW0_S1 = np.log(PW0_S1)
logPW0_S0 = np.log(PW0_S0)

##
new = "no viagra no life"
newX = v.transform([new]).toarray()

# try spam S=1
# pick log(PW0_S1) if W=0
# pick log(PW1_S1) if W=1

lS1 = np.where(newX == 1, logPW1_S1, logPW0_S1).sum() +\
      logPS1
# try  non-spam S=0
lS0 = np.where(newX == 1, logPW1_S0, logPW0_S0).sum() +\
      logPS0
print(lS1, lS0)

# alternatively, do w/matrices
lS1 = newX @ logPW1_S1 + (1 - newX) @ logPW0_S1 +\
      logPS1
lS0 = newX @ logPW1_S0 + (1 - newX) @ logPW0_S0 +\
      logPS0
print(lS1, lS0)
# here we get into trouble because 0*inf terms
# but it works when we add smoothing and there
# are no infinities
