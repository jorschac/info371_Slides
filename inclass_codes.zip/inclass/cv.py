#!/usr/bin/env python3
##
from sklearn.model_selection import cross_validate
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np

## Example with random data
n = 100
x1 = np.random.normal(size=n)
x2 = np.random.normal(size=n)
x3 = np.random.normal(size=n)
x4 = np.random.normal(size=n)
y = x1 + np.random.normal(scale=0.5, size=n)
#
X1 = x1.reshape((-1,1))
X2 = np.stack((x1, x2), axis=1)
X3 = np.stack((x1, x2, x3), axis=1)
X4 = np.stack((x1, x2, x3, x4), axis=1)


## Set up models

m = LinearRegression()
res = m.fit(X4, y)
print("coefs:", m.coef_)

## do CV
cv1 = cross_validate(m, X1, y, scoring=["r2", "explained_variance", "neg_mean_squared_error"],
                    cv = 5)
print(cv1["test_r2"])
print(cv1["test_explained_variance"])
print(cv1["test_neg_mean_squared_error"])
print("MSE model 1:", -np.mean(cv1["test_neg_mean_squared_error"]))

cv2 = cross_validate(m, X2, y, scoring=["r2", "explained_variance", "neg_mean_squared_error"],
                    cv = 5)
print("MSE model 2:", -np.mean(cv2["test_neg_mean_squared_error"]))

cv3 = cross_validate(m, X3, y, scoring=["r2", "explained_variance", "neg_mean_squared_error"],
                    cv = 5)
print("MSE model 3:", -np.mean(cv3["test_neg_mean_squared_error"]))

cv4 = cross_validate(m, X4, y, scoring=["r2", "explained_variance", "neg_mean_squared_error"],
                    cv = 5)
print("MSE model 4:", -np.mean(cv4["test_neg_mean_squared_error"]))


## ---------- Exercise
## 1. read boston housing data
## 2. split the data into target ("medv") and features (everything else)
## 3. select a few features (e.g. 1,2,4)
## 4. run a linear regression model using these features
## 5. cross-validate the MSE
## 6. try some other features and repeat

## Here is the code skeleton:
boston = pd.read_csv("../../data/boston.csv.bz2", sep="\t")
X = boston.drop("medv", axis=1).values
y = boston.medv.values

i = [1, 2, 4]
Xi = X[:, i]
m = LinearRegression()
# ...

i = [2, 3, 5, 10]
# ...
