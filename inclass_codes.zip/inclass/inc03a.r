> T <- c(0,0,0,1,1,1)
> y <- T + rnorm(6, sd=0.3)
> y
[1]  0.02319094 -0.08906059 -0.35497267  1.00338781  1.29748031  1.47819024
> data <- data.frame(y=y, treatment=T)
> data
            y treatment
1  0.02319094         0
2 -0.08906059         0
3 -0.35497267         0
4  1.00338781         1
5  1.29748031         1
6  1.47819024         1
> library(dplyr)

Attaching package: ‘dplyr’

The following objects are masked from ‘package:stats’:

    filter, lag

The following objects are masked from ‘package:base’:

    intersect, setdiff, setequal, union

> data %>% group_by(treatment) %>% summarize(mean(y))
# A tibble: 2 x 2
  treatment `mean(y)`
      <dbl>     <dbl>
1         0    -0.140=
2         1     1.26 
> 1.26 - (-0.140)
[1] 1.4
> data
            y treatment
1  0.02319094         0
2 -0.08906059         0
3 -0.35497267         0
4  1.00338781         1
5  1.29748031         1
6  1.47819024         1
> summary(lm(y ~ treatment, data=data))

Call:
lm(formula = y ~ treatment, data = data)

Residuals:
       1        2        3        4        5        6 
 0.16347  0.05122 -0.21469 -0.25630  0.03779  0.21850 

Coefficients:
            Estimate Std. Error t value Pr(>|t|)   
(Intercept)  -0.1403     0.1259  -1.114  0.32772   
treatment     1.4000     0.1781   7.861  0.00142 **
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 0.2181 on 4 degrees of freedom
Multiple R-squared:  0.9392,	Adjusted R-squared:  0.924 
F-statistic: 61.79 on 1 and 4 DF,  p-value: 0.001415

> covid  <- read.delim("data/covid-scandinavia.csv.bz2")
> tail(covid)
    country       date      type count   lockdown   growth
643 Finland 2020-04-11 Confirmed  2905 2020-03-18 4.911520
644 Finland 2020-04-11    Deaths    49 2020-03-18 2.083333
645  Norway 2020-04-11 Confirmed  6409 2020-03-12 1.504593
646  Norway 2020-04-11    Deaths   119 2020-03-12 5.309735
647  Sweden 2020-04-11 Confirmed 10151            4.811564
648  Sweden 2020-04-11    Deaths   887            1.954023
> covid <- covid %>% mutate(SAH = country != "Sweden")
> tail(covid)
    country       date      type count   lockdown   growth   SAH
643 Finland 2020-04-11 Confirmed  2905 2020-03-18 4.911520  TRUE
644 Finland 2020-04-11    Deaths    49 2020-03-18 2.083333  TRUE
645  Norway 2020-04-11 Confirmed  6409 2020-03-12 1.504593  TRUE
646  Norway 2020-04-11    Deaths   119 2020-03-12 5.309735  TRUE
647  Sweden 2020-04-11 Confirmed 10151            4.811564 FALSE
648  Sweden 2020-04-11    Deaths   887            1.954023 FALSE
> covid %>%
  filter(type == "Confirmed") %>%
  filter(count > 100) %>% tail()
covid %>%
+   filter(type == "Confirmed") %>%
+   filter(count > 100) %>% tail()
> 
    country       date      type count   lockdown   growth   SAH
132  Norway 2020-04-10 Confirmed  6314 2020-03-12 1.658348  TRUE
133  Sweden 2020-04-10 Confirmed  9685            5.951209 FALSE
134 Denmark 2020-04-11 Confirmed  6191 2020-03-11 2.943133  TRUE
135 Finland 2020-04-11 Confirmed  2905 2020-03-18 4.911520  TRUE
136  Norway 2020-04-11 Confirmed  6409 2020-03-12 1.504593  TRUE
137  Sweden 2020-04-11 Confirmed 10151            4.811564 FALSE
> unique(covid$lockdown)
[1] 2020-03-11 2020-03-18 2020-03-12           
Levels:  2020-03-11 2020-03-12 2020-03-18
> covidFinal <- covid %>%
  filter(type == "Confirmed") %>%
  filter(count > 100) %>%
  mutate(date = as.Date(date)) %>%
  filter(date > as.Date("2018-03-18"))
covidFinal <- covid %>%
+   filter(type == "Confirmed") %>%
+   filter(count > 100) %>%
+   mutate(date = as.Date(date)) %>%
+   filter(date > as.Date("2018-03-18"))
> covidFinal %>% tail()
    country       date      type count   lockdown   growth   SAH
132  Norway 2020-04-10 Confirmed  6314 2020-03-12 1.658348  TRUE
133  Sweden 2020-04-10 Confirmed  9685            5.951209 FALSE
134 Denmark 2020-04-11 Confirmed  6191 2020-03-11 2.943133  TRUE
135 Finland 2020-04-11 Confirmed  2905 2020-03-18 4.911520  TRUE
136  Norway 2020-04-11 Confirmed  6409 2020-03-12 1.504593  TRUE
137  Sweden 2020-04-11 Confirmed 10151            4.811564 FALSE
> summary(lm(growth ~ SAH, data=covidFinal))

Call:
lm(formula = growth ~ SAH, data = covidFinal)

Residuals:
    Min      1Q  Median      3Q     Max 
-15.096  -8.706  -6.119  -2.175 171.860 

Coefficients:
            Estimate Std. Error t value Pr(>|t|)    
(Intercept)   14.044      3.897   3.604  0.00044 ***
SAHTRUE        1.052      4.562   0.231  0.81796    
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 23.71 on 135 degrees of freedom
Multiple R-squared:  0.0003938,	Adjusted R-squared:  -0.007011 
F-statistic: 0.05318 on 1 and 135 DF,  p-value: 0.818

> # count > 10 for deaths, for cases we had count > 100
> covidFinal <- covid %>%
  filter(type == "Deaths") %>%
  filter(count > 10) %>%
  mutate(date = as.Date(date)) %>%
  filter(date > as.Date("2018-03-18"))
covidFinal <- covid %>%
+   filter(type == "Deaths") %>%
+   filter(count > 10) %>%
+   mutate(date = as.Date(date)) %>%
+   filter(date > as.Date("2018-03-18"))
> summary(lm(growth ~ SAH, data=covidFinal))

Call:
lm(formula = growth ~ SAH, data = covidFinal)

Residuals:
    Min      1Q  Median      3Q     Max 
-21.576 -10.082  -2.360   5.452  69.247 

Coefficients:
            Estimate Std. Error t value Pr(>|t|)    
(Intercept)   21.576      2.996   7.202 3.43e-10 ***
SAHTRUE       -6.208      3.590  -1.729   0.0878 .  
---
Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

Residual standard error: 14.68 on 77 degrees of freedom
Multiple R-squared:  0.03738,	Adjusted R-squared:  0.02488 
F-statistic:  2.99 on 1 and 77 DF,  p-value: 0.0878

> 